set autoindent
set expandtab
set fileencoding=utf-8
set hlsearch
set shiftwidth=2
set noignorecase
set nosmartcase
set tabstop=2
set hidden
set keywordprg=dict
" CVE-2019-12735
set nomodeline
" Stop messing with the xterm title bar!
set notitle
set pastetoggle=<C-Y>
set mouse=

syntax on
filetype plugin on
filetype indent on

" Press <F2> to insert YYYY-MM-DD separator
map <F2> <Esc>:normal 3o<Esc>:r!date +\%Y-\%m-\%d<CR>:normal yypVr-o<CR>:startinsert<CR><CR>

" Press <F3> to insert ----- separator.
nmap <F3> <Esc>:startinsert<CR><End><CR><Home><CR>-----<CR><CR>
imap <F3> <Esc>:startinsert<CR><End><CR><Home><CR>-----<CR><CR>

" No more searching for 'asdf' to turn off highlighting!
" Ctrl+/ = 31 decimal = ASCII 'US' (Unit Separator) (in roxterm)
" Ctrl+/ = 127 decimal = ASCII 'DEL' (in Linux console)
map  <Esc>:nohlsearch<CR>:<CR>
map  <Esc>:nohlsearch<CR>:<CR>

" Ctrl+N / Ctrl+P is easier than :n and :prev
map <C-n> :next<CR>
map <C-p> :prev<CR>

" Don't open the help when I accidentally press F1.
map <F1> :echo "<F1>"<CR>
imap <F1> <lt>F1>

" Avoid loading matchparen plugin
let loaded_matchparen = 1

" When editing a file, always jump to the last cursor position
autocmd BufReadPost *
    \ if ! exists("g:leave_my_cursor_position_alone") |
    \     if line("'\"") > 0 && line ("'\"") <= line("$") |
    \         exe "normal g'\"" |
    \     endif |
    \ endif

autocmd BufReadPost **doc/notes
    \ set ignorecase |
    \ set nosmartcase

autocmd BufReadPost *.py
    \ set shiftwidth=4 |
    \ set tabstop=4 |
    \ set noignorecase |
    \ set smartcase
